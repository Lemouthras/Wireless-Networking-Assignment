clear all
% Measurements
Signal = [-63, -62.5, -66, -57.3, -59.5, -44, -51.5, -61.5, -58.5, -60.5, -60.7, -59.5, -54.5, -44.5];
No_Signal = [-77, -74.5, -76.5, -78.6, -78.4, -77.4, -78.7, -78, -77.5, -76.7, -77.4, -78.2, -77.5, -78.5];
% -------------------------------------------------------------------------
% Average Power and Deviation
Average_Signal = sum ( Signal ) / size ( Signal , 2 ) ;
Average_No_Signal = sum ( No_Signal ) / size ( Signal , 2 ) ;

Signal_Deviation = std ( Signal );
No_Signal_Deviation = std ( No_Signal );
% -------------------------------------------------------------------------
% target absent
Pnotarget = makedist('Normal','mu',Average_No_Signal,'sigma',No_Signal_Deviation);
% target present 
Ptarget = makedist('Normal','mu',Average_Signal,'sigma',Signal_Deviation);
% threshold -60 dB
threshold = -70; 
% x-Axis dB
Level = -90:0.1:-40;
% prob of false alarm
Pfa = 1-cdf(Pnotarget,threshold);
% prob detection
Pd = 1 -cdf(Ptarget,threshold);

Prob_detection = qfunc((threshold - (-57.39)) / 6.6 ) ;
Prob_false_alarm = qfunc((threshold - (-77.49)) / 1.1 ) ;
%%
figure(1);
plot(Level,Pnotarget.pdf(Level));
hold on
plot(Level,Ptarget.pdf(Level),'m');
title('RTL-SDR detection probability')
hold on
Y =0:0.1:0.3;
X = threshold * ones(size(Y));
plot(X, Y,'r--')
legend('No Signal','Signal','threshold')
xlabel ('Level (dB)')
%%
% prob of false alarm
Pfa_ROC = 1 -cdf(Pnotarget,Level); 
% prob of detection
Pd_ROC = 1 -cdf(Ptarget,Level); 
figure(2);
plot(Pfa_ROC,Pd_ROC);
title('ROC curve')
ylabel ('Probability of Detection')
xlabel ('Probability of False Alarm')





