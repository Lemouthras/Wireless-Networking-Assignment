#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/applications-module.h"
#include "ns3/wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/internet-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/random-variable-stream.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "ns3/netanim-module.h"
#include "ns3/buildings-propagation-loss-model.h"
#include "ns3/propagation-environment.h"
using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("TestWiFi");

int main (int argc, char *argv[])
{

int mod = 1;
CommandLine cmd;
cmd.AddValue("LossModel", "Friis = 1 , LogDistance = 2", mod);
cmd.Parse (argc, argv);

//Files for results
FILE *ptr1,*ptr2;
int av_value = 5;
double Total_Throughput = 0.0; 
int64x64_t Total_Delay = 0.0; 
double StartTime = 0.0;
double StopTime = 5;

//Number of Nodes and payload
int nNodes_arr[] ={2,4,6,8,10,12,14,16,18,20};
uint32_t payloadSize = 1472 ;
uint32_t maxPacket = 10000;
int nNodes;

StringValue DataRate;
DataRate = StringValue("DsssRate11Mbps");

// Create randomness based on time
time_t timex;
time(&timex);
RngSeedManager::SetSeed(timex);
RngSeedManager::SetRun(1);

for(int z = 21 ; z <24; z=z+2){
for(int l = 7 ; l <14; l=l+2){
for(int k = 0 ; k <10; k++){

Total_Throughput=0;
Total_Delay=0;

for(int p = 0 ; p<av_value; p++){
nNodes = nNodes_arr[k];

// Access point
NodeContainer wifiApNode;
wifiApNode.Create (1);

// Nodes
NodeContainer wifiStaNodes;
wifiStaNodes.Create (nNodes);

YansWifiPhyHelper phy = YansWifiPhyHelper::Default ();
phy.Set ("RxGain", DoubleValue (0) );

YansWifiChannelHelper channel;
channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");

if (mod == 1)
channel.AddPropagationLoss ("ns3::FriisPropagationLossModel");

else if (mod ==2)
channel.AddPropagationLoss ("ns3::LogDistancePropagationLossModel");

phy.SetChannel (channel.Create ());

WifiHelper wifi = WifiHelper::Default ();
wifi.SetStandard (WIFI_PHY_STANDARD_80211b);

// MAC parameter
wifi.SetRemoteStationManager ("ns3::ConstantRateWifiManager","DataMode", DataRate,"ControlMode", DataRate);

NqosWifiMacHelper mac = NqosWifiMacHelper::Default ();

// configure SSID
Ssid ssid = Ssid ("TestWifi");
mac.SetType ("ns3::StaWifiMac","Ssid", SsidValue (ssid),"ActiveProbing", BooleanValue (false));

NetDeviceContainer staDevices;
staDevices = wifi.Install (phy, mac, wifiStaNodes);
mac.SetType ("ns3::ApWifiMac","Ssid", SsidValue (ssid));

NetDeviceContainer apDevice;
apDevice = wifi.Install (phy, mac, wifiApNode);

//Change SIFS and Slot Time
Config::Set ("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Mac/Sifs", TimeValue (MicroSeconds (l)));
Config::Set ("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Mac/Slot", TimeValue (MicroSeconds (z)));

// Configure nodes mobility
MobilityHelper mobility;

// Random Walk 2D Node Mobility Model
mobility.SetMobilityModel ("ns3::RandomWalk2dMobilityModel",
"Bounds", RectangleValue (Rectangle (-1000, 1000, -1000, 1000)),
"Distance", ns3::DoubleValue (300.0));

mobility.Install (wifiStaNodes);

// Constant Mobility for Access Point
mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
mobility.Install (wifiApNode);
//std::cout << "Node mobility configured.." << '\n';

// Internet stack
InternetStackHelper stack;
stack.Install (wifiApNode);
stack.Install (wifiStaNodes);

// Configure IPv4 address
Ipv4AddressHelper address;
Ipv4Address addr;
address.SetBase ("10.1.1.0", "255.255.255.0");
Ipv4InterfaceContainer staNodesInterface;
Ipv4InterfaceContainer apNodeInterface;
staNodesInterface = address.Assign (staDevices);
apNodeInterface = address.Assign (apDevice);

// Create traffic generator (UDP)
ApplicationContainer serverApp;
UdpServerHelper myServer (4001); //port 4001
serverApp = myServer.Install (wifiStaNodes.Get (0));
serverApp.Start (Seconds(StartTime));
serverApp.Stop (Seconds(StopTime));

UdpClientHelper myClient (apNodeInterface.GetAddress (0), 4001); //port 4001
myClient.SetAttribute ("MaxPackets", UintegerValue (maxPacket));
myClient.SetAttribute ("Interval", TimeValue (Time ("0.002"))); //packets/s
myClient.SetAttribute ("PacketSize", UintegerValue (payloadSize));

ApplicationContainer clientApp = myClient.Install (wifiStaNodes.Get (0));

for(int s = 1 ; s <nNodes; s++)
clientApp.Add (myClient.Install (wifiStaNodes.Get (s)));

clientApp.Start (Seconds(StartTime));
clientApp.Stop (Seconds(StopTime+5));

// Throughput & Delay with Flow_monitor
FlowMonitorHelper flowmon;
Ptr<FlowMonitor> monitor = flowmon.InstallAll();

Simulator::Stop (Seconds(StopTime+2));
Simulator::Run ();

monitor->CheckForLostPackets ();

Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier> (flowmon.GetClassifier ());
std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats ();

for (std::map<FlowId, FlowMonitor::FlowStats>::const_iterator i = stats.begin (); i != stats.end (); ++i)
{

Total_Throughput = Total_Throughput + i->second.rxBytes * 8.0 / (i->second.timeLastRxPacket.GetSeconds()- i->second.timeFirstTxPacket.GetSeconds()) / 1024;
Total_Delay = Total_Delay + i->second.delaySum / ( 1000000 * i->second.rxPackets );
}
Simulator::Destroy ();
}
Total_Throughput = Total_Throughput / av_value;
Total_Delay = Total_Delay / av_value;

std::cout << " Final Throughput (Kbps): " << Total_Throughput << "\n";
std::cout << " Final Delay (ms): " << Total_Delay  << "\n";
 
// write to file
if (mod == 1)
{
ptr1 = fopen("throughput_friis_average.txt","a");
ptr2 = fopen("delay_friis_average.txt","a");

fprintf(ptr1,"%g\n",Total_Throughput);
fprintf(ptr2,"%g\n",Total_Delay.GetDouble() );
if (k == 9 ){
fprintf(ptr1,"\n");
fprintf(ptr2,"\n");
}
if ( l==13 && k==9 ){
fprintf(ptr1,"\n\n\n");
fprintf(ptr2,"\n\n\n");
}
fclose(ptr1);
fclose(ptr2);
}

else if (mod == 2)
{
ptr1 = fopen("throughput_log_average.txt","a");
ptr2 = fopen("delay_log_average.txt","a");

fprintf(ptr1,"%g\n",Total_Throughput);
fprintf(ptr2,"%g\n",Total_Delay.GetDouble() );
if (k == 9 ){
fprintf(ptr1,"\n");
fprintf(ptr2,"\n");
}
if ( l==13 && k==9 ){
fprintf(ptr1,"\n\n\n");
fprintf(ptr2,"\n\n\n");
}
fclose(ptr1);
fclose(ptr2);
}
//end writing to file 
} } }
return 0;
}
